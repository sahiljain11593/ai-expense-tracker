# Bank Statements

Upload CSV and PDF statements for reconciliation.

- Place files here: /bank/statements/
- Examples: 2024-07.csv, 2024-07.pdf
- Do NOT commit secrets.
